from django.contrib import messages
from django.shortcuts import render, redirect
from django.http import HttpResponse
from.models import Place
# Create your views here.

def demo(request):
    obj = Place.objects.all()
    return render(request,"index.html",{'result':obj})
def register(request, user=None):
    if request.method== 'POST':
        username=request.POST['username']
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        email = request.POST['email']
        password = request.POST['password']
        cpassword = request.POST['password1']
        if password==cpassword:
            if user.objects.filter(username=username).exists():
                messages.info(request,"username already exist")
                return redirect('credentials')
            elif user.objects.filter(email=email).exists():
                messages.info(request,"email already exist")
                return redirect('credentials')
            else:
             user=user.objects.create_user(username=username,password=password,first_name=first_name,last_name=last_name,email=email)

             user.save();
             print("user created")
        else:
         messages.info(request,"password missmatch")
         return redirect('credentials')
        return redirect('/')
    return render(request,"register.html")
